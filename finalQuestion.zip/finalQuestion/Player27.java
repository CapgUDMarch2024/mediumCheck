package com.com.capgemin.finalQuestion;

import java.util.*;
import java.io.*;

public class Player27 implements Comparable<Player27>
{
    Scanner read;
    PrintWriter write;

    private String playerid;
    private int playerscore;

    int x = 0;
    ArrayList<String> n = new ArrayList<String>();
    ArrayList<Integer> s = new ArrayList<Integer>();

    public Player27(String name, int score)
    {
        playerid = name;
        playerscore = score;
    }


    static class ScoreComparator implements Comparator <Player27>
    {
        public int compare(Player27 lf1, Player27 lf2)
        {
            int scoreA = lf1.getScore ();
            int scoreB = lf2.getScore ();

            if (scoreA == scoreB)
            {
                return 0;
            }

            else if (scoreA > scoreB)
            {
                return 1;
            }
            else
            {
                return -1;
            }
        }
    }

    public String getName()
    {
        return playerid;
    }

    public int getScore()
    {
        return playerscore;
    }

    public String toString ()
    {
        return playerid+" "+playerscore;
    }

    public int compareTo(Player27 lf)
    {
        return getName ().compareTo (lf.getName ());
    }

    public void loadScores()
    {


        try
        {
            read = new Scanner (new FileReader ("lbout.txt"));

            while (read.hasNext ())
            {

                n.add (x, read.next ());
                s.add(x, read.nextInt ());
                ++x;
            }

        }
        catch (FileNotFoundException fnfe)
        {
            System.out.println(fnfe+": FILE NOT FOUND!");
        }
        catch (InputMismatchException ime)
        {
            System.out.println(ime+": INVALID DATA!");
        }
        catch (Exception e)
        {
            System.out.println(e);
        }


    }

    public void sortScores()
    {

    }

    public void writeScores()
    {
        try
        {
            loadScores ();
            n.add (playerid);
            s.add(playerscore);
            //sort -- add players' scores
            write = new PrintWriter ("lbout.txt");

            for (int z = 0; z < 5; ++z)
            {

                write.print(n.get(z)+" ");
                write.println (s.get(z));

            }
            write.close ();
            //displayscores();


        }

        catch (InputMismatchException ime)
        {
            System.out.println(ime+": INVALID DATA!");
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }

    public void displayScores()
    {

        /*call class that will display gui with top 5 scorers*/
    }

    public static void main (String[] args) {

        Player27 x = new Player27("String", 40);
        x.writeScores ();
    }
}

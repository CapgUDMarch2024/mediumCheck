package com.com.capgemin.finalQuestion;

public class FindContinueSubArray21 {
    public static void main(String[] args){
        int[] arr1 ={19,12,7,29,6,2,11,4,8};
        int target = 19;// 12+7,  6+2+11
        int n= arr1.length;
        findSubArray(arr1, n, target);
    }
    public static void findSubArray(int[] a, int n, int sum){
        int[] arr= new int[n];
        for(int i=0; i<n-2; i++){

            if(a[i] == sum) {
                arr = new int[]{a[i]};
                System.out.println("Sub array is::"+"["+ a[i] +"]");

            }
            if(a[i] + a[i+1] == sum) {
                arr = new int[]{a[i], a[i+1]};
                System.out.println("Sub array is::"+"["+ a[i] +","+a[i+1]+"]");
            }
            if(a[i] + a[i+1] + a[i+2] == sum){
                arr = new int[]{a[i], a[i+1], a[i+2]};
                System.out.println("Sub array is::"+"["+ a[i] +","+a[i+1]+ ","+a[i+2]+"]");
            }
        }
        //System.out.println("Sub array is::"+ Arrays.toString(arr));
    }
}

package com.com.capgemin.finalQuestion;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;

public class sortByPatternStringArray24 {
    // For storing priority of each character
    static HashMap<Character, Integer> mp = new HashMap<>();

    // class implementing Comparator interface
    class comp implements Comparator<String>
    {

        // Custom comparator function for sort
        public int compare(String a, String b)
        {

            // Loop through the minimum size
            // between two words
            for (int i = 0;
                 i < Math.min(a.length(), b.length());
                 i++) {

                // Check if the characters
                // at position i are different,
                // then the word containing lower
                // valued character is smaller
                if (mp.get(a.charAt(i))
                        != mp.get(b.charAt(i)))
                    return mp.get(a.charAt(i))
                            - mp.get(b.charAt(i));
            }

            /* When loop breaks without returning, it
            means the prefix of both words were same
            till the execution of the loop.
            Now, the word with the smaller size will
            occur before in sorted order
            */
            return (a.length() - b.length());
        }
    }

    // Function to print the
    // new sorted array of strings
    static void printSorted(String[] words, String order)
    {

        // Mapping each character
        // to its occurrence position
        for (int i = 0; i < order.length(); i++)
            mp.put(order.charAt(i), i);

        // Sorting with custom sort function
        Arrays.sort(words, new sortByPatternStringArray24().new comp());

        // Printing the sorted order of words
        for (String x : words)
            System.out.print(x + " ");
    }

    public static void main(String[] args)
    {
        String[] words = {  "Ajay", "Raja", "Keshav", "List", "Set", "Elephant", "Drone"};
        String order = "TESARDLK";
        printSorted(words, order);
    }
}

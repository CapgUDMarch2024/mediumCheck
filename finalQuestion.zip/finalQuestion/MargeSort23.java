package com.com.capgemin.finalQuestion;

import java.util.Arrays;
import java.util.stream.IntStream;

public class MargeSort23 {
    public static void main(String[] args) {
        int arr1[] = {-2, 1, 3, 5, 7};
        int arr2[] = {2, 4, 6, 8, 9, 15};
        int[] arr3 = IntStream.concat(Arrays.stream(arr1), Arrays.stream(arr2)).sorted().toArray();
        Arrays.stream(arr3).forEach(e -> System.out.println(e));
    }
}

package com.capgemn.simpleProgram2nd;

public class NoOfCharInString15 {
    public static void main(String args[]){
        String str="viveksingh";
        char[] charArr=str.toCharArray();
        System.out.println(charArr.length);
    }
}

package com.capgemn.simpleProgram2nd;

public class Employee implements Comparable<Employee>{
    int id;
    String Name;

    public Employee() {}
    public Employee(int id, String name) {
        this.id = id;
        Name = name;
    }

    @Override
    public int compareTo(Employee o) {
        if (id > o.id) {
            return 1;
        }
        else if (id < o.id) {
            return -1;
        }
        else {
            return 0;
        }
    }
    // Override the compareTo() method

}

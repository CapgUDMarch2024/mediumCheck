package com.capgemn.simpleProgram2nd;

import java.util.HashMap;

public class CountCharInString14 {
    public static void main(String[] args) {
        String str="vivekkumariisingh";
        char[] charArr=str.toCharArray();

        HashMap<Character,Integer> hm=new HashMap<Character, Integer>();
        int count=1;
        for(int i=0 ; i < charArr.length ;i++){
            if(hm.containsKey(charArr[i])){
                hm.put(charArr[i] ,count+1);
            }else{
                hm.put(charArr[i] ,1);
            }
        }
        System.out.println(hm);
    }
}

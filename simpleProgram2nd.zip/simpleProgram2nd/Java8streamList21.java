package com.capgemn.simpleProgram2nd;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Java8streamList21 {
    public static void main(String argc[]) {
        List<Integer> numbers = Arrays.asList(1, 43, 15, 66, 87, 89, 9, 10, 22, 34, 23, 89, 54);

        //3. get all prime numbers
       numbers.stream().collect(Collectors.toList()).forEach(e->System.out.println(e));

       System.out.println("======================================================");
        //1. get only single digit number

        numbers.stream().filter(num->num >=0).filter(num->num <=9).forEach(e->System.out.println(e));

        System.out.println("======================================================");
        //2.  {even: evennumber, odd: oddnumbers}

        numbers.stream().filter(num->num%2 == 0).forEach(e->System.out.println(e));
        System.out.println("=======================Odd===============================");
        numbers.stream().filter(num->num%2 != 0).forEach(e->System.out.println(e));
    }
}
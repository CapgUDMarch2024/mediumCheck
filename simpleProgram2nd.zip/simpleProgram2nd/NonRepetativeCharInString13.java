package com.capgemn.simpleProgram2nd;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class NonRepetativeCharInString13 {
    public static void main(String[] args) {
        Map<Character, Integer> map = new HashMap<>();

        Scanner scan = new Scanner(System.in);
        System.out.println("Input First Word: ");
         String s=scan.nextLine();
        char[] chars = s.toCharArray();

        for(Character ch:chars){
            if(map.containsKey(ch)){
                map.put(ch, map.get(ch)+1);
            } else {
                map.put(ch, 1);
            }
        }

        Set<Character> keys = map.keySet();
        for(Character ch:keys){
            if(map.get(ch) == 1){
                System.out.println(ch+" ");
            }
        }
    }
}

package com.capgemn.simpleProgram2nd;

import java.util.TreeSet;

public class TreeSetEmployee22 {
    public static void main(String argc[]){
    Employee emp =new Employee(101 , "Vivek");
    Employee emp1 =new Employee(102 , "Nikki");

        TreeSet<Employee> ts=new TreeSet<Employee>();
        ts.add(emp);
        ts.add(emp1);

        System.out.println(ts.size());
}}

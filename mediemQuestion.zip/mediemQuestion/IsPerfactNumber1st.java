package com.cagemini.mediemQuestion;
import java.util.Scanner;

//For example: 6 is the first perfect number Proper divisors of 6 are 1, 2, 3
//Sum of its proper divisors = 1 + 2 + 3 = 6.Hence 6 is a perfect number.

public class IsPerfactNumber1st {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int min = in.nextInt();

        int max = in.nextInt();

        System.out.println(min +" to "+max+" perfect numbers:");
        for (int i = min; i <= max; i++)
        {
            int sum = 0;
            for (int j = 1; j < i; j++)
            {
                if (i % j == 0)
                    sum = sum + j;
            }
            if (sum == i)
                System.out.println(i+", ");
        }

    }
}

// 6,28
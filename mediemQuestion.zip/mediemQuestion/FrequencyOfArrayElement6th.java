package com.cagemini.mediemQuestion;

import java.util.HashMap;

public class FrequencyOfArrayElement6th {
    static void countdigit(int x[]) {
        HashMap<Integer,Integer> digits=new HashMap<Integer,Integer>();
        for (int i : x){
            if (digits.containsKey(i)){
                digits.put(i, digits.get(i)+1);
            } else {
                digits.put(i, 1);
            }
        }
        for (int key:digits.keySet()){
            if(digits.get(key)==1){
            System.out.println(key+"="+digits.get(key));
        }}
    }

    public static void main(String s[]) {
        countdigit(new int[] { 1, 4,5, 2, 3, 4, 3, 3 });
    }
}

package com.cagemini.mediemQuestion;

import java.util.HashSet;

public class UnicSubstringGivenLength9 {
    static void result(String s, int n)
    {
        // set to store the Strings
        HashSet<String> st = new HashSet<String>();

        for (int i = 0; i < (int)s.length(); i++)
        {
            String ans = "";
            for (int j = i; j < (int)s.length(); j++)
            {
                ans += s.charAt(j);

                // if the size of the String
                // is equal to 1 then insert
                if (ans.length()== n)
                {

                    // inserting unique
                    // sub-String of length L
                    st.add(ans);
                    break;
                }
            }
        }

        // Printing the set of Strings
        for (String it : st)
            System.out.print(it + " ");
    }

    // Driver Code
    public static void main(String[] args)
    {
        String s = "abca";
        int n = 2;

        // Function calling
        result(s, n);
    }
}

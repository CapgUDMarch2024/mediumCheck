package com.cagemini.mediemQuestion;

import java.util.HashMap;
import java.util.Map;

public class NonRepeatativeCharInString7th {

    public static char firstNonRepeatingCharacterMyVersion(String input) {
        Map<String,Integer> map = new HashMap<>();
        // first iteration put in a map the number of times a char appears. Linear O(n)=n
        for (char c : input.toCharArray()) {
            String character = String.valueOf(c);
            if(map.containsKey(character)){
                map.put(character,map.get(character) + 1);
            } else {
                map.put(character,1);
            }
        }
        // Second iteration look for first element with one element.
        for (char c : input.toCharArray()) {
            String character = String.valueOf(c);
            if(map.get(character) == 1){
                return c;
            }
        }
        return (0);

    }

    public static void main(String s[]) {
    String[] strArr={"array" ,"apple" ,"rat"};
    for(int i=0 ; i < strArr.length ;i++){
       System.out.println(firstNonRepeatingCharacterMyVersion(strArr[i]));
    }
    }
}

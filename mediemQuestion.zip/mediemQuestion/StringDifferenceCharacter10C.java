package com.cagemini.mediemQuestion;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class StringDifferenceCharacter10C {
    public static List<String> findNotMatching(String sourceStr, String anotherStr){
        StringTokenizer at = new StringTokenizer(sourceStr, " ");
        StringTokenizer bt = null;
        int i = 0, token_count = 0;
        String token = null;
        boolean flag = false;
        List<String> missingWords = new ArrayList<>();
        while (at.hasMoreTokens()) {
            token = at.nextToken();
            bt = new StringTokenizer(anotherStr, " ");
            token_count = bt.countTokens();
            while (i < token_count) {
                String s = bt.nextToken();
                if (token.equals(s)) {
                    flag = true;
                    break;
                } else {
                    flag = false;
                }
                i++;
            }
            i = 0;
            if (flag == false)
                missingWords.add(token);
        }
        return missingWords;
    }
    public static void main (String[] args) {
        String str="abcdefghijklmnopqrstuvwxyz";
        String str2="Online test with GS client ";
        System.out.println(findNotMatching(str, str2));
    }
}

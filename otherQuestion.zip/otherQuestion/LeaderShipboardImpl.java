package com.capgemini.otherQuestion;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LeaderShipboardImpl {
    public static void main(String[] args) {
        //   27. Players - Leaderboard
   //The leaderboard should display Players in the order of their level and Scores.
   //Logic -Consider Player class with fields -> Name, Level and Score
   //Needs to sort the players list - first sort by Level and then by score"
       LeaderShipboard l1= new LeaderShipboard();
       l1.setName("A");
       l1.setLevel(1);
       l1.setScore(90);

       LeaderShipboard l2= new LeaderShipboard();
       l2.setName("B");
       l2.setLevel(1);
       l2.setScore(100);

       LeaderShipboard l3= new LeaderShipboard();

       l3.setName("C");
       l3.setLevel(1);
       l3.setScore(10);

       List<LeaderShipboard> lists= new ArrayList<>();
       lists.add(l1);
       lists.add(l2);
       lists.add(l3);

       Collections.sort(lists,new LeaderShipboardComparator());
       System.out.println(lists);
       for(int i=0;i<lists.size();i++)
       {
        System.out.println(lists.get(i).getName()+": "+ lists.get(i).getLevel()+": "+lists.get(i).getScore());
       }



   
       }
    
}

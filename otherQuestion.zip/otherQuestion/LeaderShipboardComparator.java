package com.capgemini.otherQuestion;

import java.util.Comparator;

public class LeaderShipboardComparator implements Comparator<LeaderShipboard> {

    @Override
    public int compare(LeaderShipboard arg0, LeaderShipboard arg1) {
        int flag= arg1.getLevel()-arg0.getLevel();
        if (flag==0) {
            flag= arg1.getScore()-arg0.getScore();
        }
        return flag;
    }
    
}

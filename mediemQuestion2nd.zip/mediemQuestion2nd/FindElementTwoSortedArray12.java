package com.capgemini.mediemQuestion2nd;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FindElementTwoSortedArray12 {
    public static void main(String[] args) {

        int[] arr1 = {2, 3, 6, 7, 9};
        int[] arr2 = {1, 4, 8, 10};

        List list = new ArrayList();

        for (int i = 0; i < arr1.length; i++) {
            list.add(arr1[i]);
        }
        for (int i = 0; i < arr2.length; i++) {
            list.add(arr2[i]);
        }
        Collections.sort(list);
        for (int i = 0; i < list.size(); i++) {
            if(list.get(i).equals(6)){
                System.out.println(i+1);
            }
        }

    }}
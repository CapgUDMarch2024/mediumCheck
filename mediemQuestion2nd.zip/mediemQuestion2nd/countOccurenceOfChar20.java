package com.capgemini.mediemQuestion2nd;

import java.util.HashMap;

public class countOccurenceOfChar20 {
    public static void main(String[] args) {
        String str="viveksingh";

        char[] chArr=str.toCharArray();
        int count=1;

        HashMap<Character,Integer> hm=new HashMap<Character,Integer> ();
        for(int i=0 ; i < chArr.length ;i++){

            if(hm.containsKey(chArr[i])){
                hm.put(chArr[i] ,count+1);
            }else{
                hm.put(chArr[i],count);
            }

        }
        System.out.println(hm);
    }
}
